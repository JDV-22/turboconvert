// TurboConvert — AdSense auto-inject
// Ce script s'injecte automatiquement dans le <head> de chaque page
(function() {
  var s = document.createElement('script');
  s.async = true;
  s.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6238323731269830';
  s.setAttribute('crossorigin', 'anonymous');
  document.head.appendChild(s);
})();
